// components/layout/AuthLayuot.tsx
import { Outlet } from 'react-router-dom';
import styled from 'styled-components';


export const AuthLayuot = () => (
  <>
      <Outlet />
  </>
);
